from House import House
class SmallHouse(House):#класс небольшой типовой дом
    def __init__(self):#уствнавливаем по умолчанию площадь
        super().__init__(40)