"""https://videouroki.net/razrabotki/zadachi-po-oop-na-python-chast-1.html
Задача 1
"""
from Human import Human
from House import House
from SmallHouse import SmallHouse
Human.default_info()
h1 = Human()
h1.info()
sh1 = SmallHouse()
h1.buy_house(sh1)
h1.earn_money(30000)
h1.buy_house(sh1)
h1.info()





