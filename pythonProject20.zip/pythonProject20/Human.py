from House import House
class  Human():#класс человек
    default_name = "Аня"#атрибуты класса
    default_age = 18
    def __init__(self,name = default_name,age = default_age,money=0,house=0):
        self.name = name
        self.age = age
        self.__money = money#приватные свойства
        self.__house = house

    def info(self):
        #справочные метод
        print("Имя:"+str(self.name)+"  возраст:"+str(self.age)+" наличие денег:"+str(self.__money)+"  наличие дома:"+str(self.__house))

    @staticmethod
    def default_info():#статический справочный метод
        print("Имя по умолчанию:"+ str(Human.default_name)+"  возраст по умолчанию:"+ str(Human.default_age))
    def __make_deal(self,home):#приватный метод покупки дома
        self.__money = self.__money - home._price
        self.__house = home

    def earn_money(self,er_money):#метод увеличивающий деньги
        self.__money = self.__money + er_money

    def buy_house(self,home):#метод покупки дома(проверки условий)
        if home._price <= self.__money:
            self.__make_deal(home)
            print("Поздравляем с покупкой!")
        else:
            print("Недостаточно средств")