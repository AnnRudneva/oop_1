class House:#класс дом
    def __init__(self,area,price=1000):
        self._area = area#динамичсекие поля
        self._price = price

    @property
    def area(self):
        return self._area

    @area.setter
    def area(self, value):
        if value <= 0:
           raise ValueError("Площадь должна быть больше 0")
        else:
            self._area = value

    @property
    def price(self):
        return self._price
    @price.setter
    def price(self, value):
        if value <= 0:
           raise ValueError("Цена должна быть больше 0")
        else:
            self._price = value

    def get_final_price(self,sale=0):#возвращает цену с учетом скидки
        #скидка взята в процентах
        return (self._price * (100-sale))/100