from Alphabet import Alphabet
from string import ascii_uppercase
class EngAlphabet(Alphabet):#класс английский алфавит
    def __init__(self):
        super().__init__("En",list(ascii_uppercase))#инициализатор на основе родительского

    __letters_num = 26#приватноое статической свойство

    def is_en_letter(self,letter):#проверка на нахождение в алфавите
        res = "Буквы нет в этом алфавите"
        if (letter in self._letters) or (letter.upper() in self._letters):
            res = "Буква есть в это алфавите"
        print (res)

    def letters_num(self):#переопределение методы вывода размера алфавита
        return self.__letters_num

    @staticmethod
    def example():#статический метод вывода примера английского текста
        print("My name is Ann.I love musical theater.")