
class Alphabet():#класс алфавит
    def __init__(self,lang,let=[]):
        self._lang = lang#динамические атрибуты
        self._letters = let

    @property
    def lang(self):
        return self._lang
    @lang.setter
    def lang(self, value):
        self._lang = value

    @property
    def letter(self):
        return self._letters

    @lang.setter
    def lang(self, value):
        self._letters = value

    def print(self):#вывод букв
        for i in self._letters:
            print(i)

    def letters_num(self):#метод вывода размера алфавита
        return len(self._letters)
