"""https://videouroki.net/razrabotki/zadachi-po-oop-na-python-chast-1.html
Задача 2
"""
from Alphabet import Alphabet
from EngAlphabet import EngAlphabet


e1 = EngAlphabet()
e1.print()
print(e1.letters_num())
e1.is_en_letter("F")
e1.is_en_letter("Щ")
e1.is_en_letter("f")
e1.example()
EngAlphabet.example()#статический метод вызывается с экземпляром класса и без него 