"""
https://metanit.com/python/practice/9.php
Создайте класс BankAccount, который представляет банковский счет.
Определите в этом классе атрибуты account_number и balance, которые представляют номер счета и баланс.
Через параметры конструктора передайте этим атрибутам начальные значения.
Также в классе определите метод add, который принимает некоторую сумму и добавляет ее на баланс счета.
И определите метод withdraw, который принимает некоторую сумму и снимает ее с баланса.
При этом с баланса нельзя снять больше, чем имеется.
Если на балансе недостаточно средств, то пользователю должно выводиться соответствующее сообщение."""
class BankAccount():#класс банковский счёт
    def __init__(self,account,balance =0):
        self.account_number = account
        self.balance = balance

    def __add__(self, other):#решила переопределить метод
        self.balance = self.balance + other.balance
        other.balance = 0

    def add(self,n):#метод пополнения счёта
        self.balance = self.balance + n

    def withdraw(self,n):#метод сбора со счёта
        if self.balance >= n:
            self.balance = self.balance - n
        else:
            print("Недостаточно средств")

b1 =BankAccount(1,100)
b2 = BankAccount(2,50)
b1 + b2
print("b1:"+str(b1.balance))
print("b2:"+str(b2.balance))
b2.add(200)
print("b2:"+str(b2.balance))
b1.withdraw(50)
print("b1:"+str(b1.balance))
