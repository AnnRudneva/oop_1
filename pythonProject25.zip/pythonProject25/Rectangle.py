"""
https://metanit.com/python/practice/9.php
Определите класс Rectangle, который представляет прямоугольник.
Через конструктор класс принимает ширину и длину и сохраняет их в атрибутах width и length соответственно.
Также этом классе определите метод area, который возвращает площадь прямоугольника, и метод perimeter,
который возвращает периметра прямоугольника."""
class Rectangle():#класс прямоугольник
    def __init__(self,w,l):
        self.width = w
        self.lenght = l

    def area(self):#площадь
        return self.width * self.lenght
    def perimeter(self):#периметр
        return (self.width + self.lenght)*2

r1 = Rectangle(2,3)
print(r1.area())
print (r1.perimeter())