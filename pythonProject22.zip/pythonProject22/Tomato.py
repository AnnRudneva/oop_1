class Tomato():#класс помидор
    states = ["Отсутствует","Цветение","Зелёный","Красный"]
    def __init__(self,index):
        self._index = index#
        self._state = Tomato.states[0]
    @property
    def index(self):
        return self._index

    @index.setter
    def index(self, value):
        if value.isnumber() == 0:
            print("Индекс должен быть числом")
        elif value < 0:
            print("Индекс должен быть больше 0")
        else:
            self._index = value

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self,value):
        if value not in Tomato.states:
            print("Неверное значение")
        else:
            self._state = value

    def grow(self):#метод роста
        if self._state == Tomato.states[-1]:
            pass
        else:
            ind =Tomato.states.index(self._state)
            self._state = Tomato.states[ind+1]

    def is_ripe(self):#метод выявления зрелости
        if self._state == Tomato.states[-1]:
            return 1
        else:
            return 0