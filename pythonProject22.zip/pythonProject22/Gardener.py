from TomatoBush import TomatoBush
class Gardener():#класс садовник
    def __init__(self,name,plant):
        self._name = name #динамическиe aтрибуты
        self._plant = plant

    @property
    def name(self):
        return self._name
    @name.setter
    def name(self,value):
        self._name = value

    @property
    def plant(self):
        return self._plant
    @plant.setter
    def plant(self,value):
        if type(value) == TomatoBush:
            self._plant = value
        else:
            print("неверные данные")

    def work(self):#метод работы
        self._plant.graw_all()


    def harvest(self):#сбор урожая
        if self._plant.all_are_ripe() == True:
            self._plant.give_away_all()
            print("Урожай собран")
        else:
            print("Не все плоды созрели!")


    @staticmethod
    def knowledge_base():#стический метод справка
        print("Занимайтесь садоводсьвом! Это интересно!")