"""https://videouroki.net/razrabotki/zadachi-po-oop-na-python-chast-1.html
Задача 3
"""
from TomatoBush import TomatoBush
from Gardener import Gardener

Gardener.knowledge_base()
t = TomatoBush(5)
g = Gardener("Tatiana",t)
g.work()
g.work()
g.harvest()
g.work()
g.work()
g.harvest()
print(t.tomatoes)