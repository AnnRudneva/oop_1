from Tomato import Tomato
class TomatoBush():# класс куст томата
    def __init__(self,l):
        list=[]
        for i in range(l):
            t1 = Tomato(i)
            list.append(t1)
        self.tomatoes = list

    def all_are_ripe(self):#метод проверки зрелости всех томаров
        res = True
        for i in self.tomatoes:
            if i.is_ripe() == 0:
                res = False
                break
        return res
    def graw_all(self):#метод созревания всех помидоров
        if self.all_are_ripe() == True :
            print("Все помидоры созрели")
        else:
            for i in self.tomatoes:
                i.grow()
            print("Хорошо поработали!")

    def give_away_all(self):#сбор урожая
        self.tomatoes =[]
