"""
https://ru.stackoverflow.com/questions/1555922/Задача-по-основам-ООП-python
Рассмотрим объект «Программист», который задаётся именем, должностью и количеством отработанных часов.
Каждая должность имеет собственный оклад (заработную плату за час работы). В нашей импровизированной компании существуют 3 должности:
Junior — с окладом 10 тугриков в час;
Middle — с окладом 15 тугриков в час;
Senior — с окладом 20 тугриков в час по умолчанию и +1 тугрик за каждое новое повышение.
Напишите класс Programmer, который инициализируется именем и должностью (отработка у нового работника равна нулю). Класс реализует следующие методы:
work(time) — отмечает новую отработку в количестве часов time;
rise() — повышает программиста;
info() — возвращает строку для бухгалтерии в формате: <имя> <количество отработанных часов>ч. <накопленная зарплата> тгр."""
class Programmer():#класс программист
    states = {"Junior":10,"Senior":20,"Middle":15}#словарь должностей и из зарплат за час
    def  __init__(self,name,state,hours=0):
        self.name = name
        self._state = state
        self.hours = hours

    @property
    def state(self):
        return self._state
    @state.setter
    def state(self,value):#защищаем должность от неправильного ввода
        if value not in Programmer.states.keys():
            print("Неверно введена должность")
        else:
            self._state = value

    def work(self,time):#метод учета отработанного времени
        self.hours = self.hours + time
        print("Время учтено")

    def rise(self):
        i1 = Programmer.states.values()
        items = list(i1)
        item = self._state

        it = Programmer.states[item]

        for i in items:
            if i <= int(it):

                items.remove(i)

        value = min(items)
        res = 0
        for key in Programmer.states:
            if Programmer.states[key] == value:
                res = key
        self._state = res

    def info(self):
        print("Имя:"+self.name+"  Часы:"+str(self.hours)+"  Зарплата:"+str(self.hours*int(Programmer.states[self._state])))


