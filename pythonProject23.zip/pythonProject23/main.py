from Programmer import Programmer
p1 = Programmer("Ann","Junior",2)
p1.info()
p1.work(3)
p1.info()
p1.rise()
p1.info()
p1.rise()
p1.info()